package testing

class TestFacility {
    String objectNrInternal
    String product

    static constraints = {
    }
}
