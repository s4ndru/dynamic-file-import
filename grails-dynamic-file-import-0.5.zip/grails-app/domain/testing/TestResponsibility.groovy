package testing

class TestResponsibility {

    String name

    static constraints = {
        name nullable: false
    }
}
