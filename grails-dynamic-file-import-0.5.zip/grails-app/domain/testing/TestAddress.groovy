package testing

class TestAddress {

    String vorname
    String nachname

    static constraints = {
    }
}
