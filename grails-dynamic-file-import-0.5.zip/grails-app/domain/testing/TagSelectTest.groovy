package testing

class TagSelectTest {

    Integer id
    String date_created
    String event_name
    String remote_address
    String session_id
    String switched_username
    String username
}
