package testing

class TestContact {

    TestAddress address

    static constraints = {
        address nullable: true
    }
}
